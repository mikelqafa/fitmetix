<?php return array (
  'reposition_cover' => 'Переставьте крышку',
);