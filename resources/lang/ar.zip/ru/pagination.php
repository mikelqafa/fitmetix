<?php return array (
  'previous' => '«Предыдущая',
  'next' => 'Следующий &quot;',
);