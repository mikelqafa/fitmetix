<?php return array (
  'reposition_cover' => 'إعادة الغطاء',
);