<?php return array (
  'reposition_cover' => 'herpositioneren deksel',
);