<?php return array (
  'password' => 'Wachtwoorden moeten ten minste zes tekens bestaan ​​en overeenkomen met de bevestiging.',
  'reset' => 'Je wachtwoord is gereset!',
  'sent' => 'We hebben per e-mail uw wachtwoord te resetten koppeling!',
  'token' => 'Dit wachtwoord reset token is ongeldig.',
  'user' => 'We kunnen een gebruiker met dat e-mail adres niet vinden.',
);