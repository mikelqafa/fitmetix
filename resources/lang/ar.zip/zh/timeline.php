<?php return array (
  'reposition_cover' => '盖重新定位',
);