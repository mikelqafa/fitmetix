<?php return array (
  'password' => 'As senhas devem ter pelo menos seis caracteres e combinar a confirmação.',
  'reset' => 'Sua senha foi alterada!',
  'sent' => 'Temos por e-mail o seu link de redefinição de senha!',
  'token' => 'Esse token de redefinição de senha é inválida.',
  'user' => 'Não podemos encontrar um usuário com esse endereço de e-mail.',
);