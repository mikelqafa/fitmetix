<?php return array (
  'reposition_cover' => 'reposicionar a cobertura',
);