<?php return array (
  'previous' => '«Anterior',
  'next' => 'Próximo &quot;',
);