<?php return array (
  'previous' => '&quot; पिछला',
  'next' => 'आगामी &quot;',
);