<?php return array (
  'reposition_cover' => 'कवर का स्थान बदलें',
);